import cave

class InventoryComponent(cave.Component):
	def start(self, scene: cave.Scene):
		self.scene = scene
		self.menuInventory = self.entity.getChild("Menu Inventory")

	def update(self):
		events = cave.getEvents()

		if events.released(cave.event.KEY_TAB):
			self.scene.paused = True
			self.menuInventory.activate(self.scene)

	def pausedUpdate(self):
		events = cave.getEvents()

		if events.released(cave.event.KEY_ESCAPE) or events.released(cave.event.KEY_TAB) or events.released(cave.event.MOUSE_RIGHT):
			self.scene.paused = False
			self.menuInventory.deactivate(self.scene)

	def end(self, scene: cave.Scene):
		pass