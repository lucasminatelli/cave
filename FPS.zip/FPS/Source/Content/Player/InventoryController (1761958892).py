import cave

class InventoryController(cave.Component):
	slotsName: str = "Slots"
    
	def add_item(self, inv, item, line, col):
		if inv[line][col] is None:
			inv[line][col] = item
			print(f"Item '{item}' added at ({line}, {col}).")
		else:
			print(f"No space at ({line}, {col}) has '{inv[line][col]}' already.")

	def replace_item(self, inv, item, line, col):
		inv[line][col] = item
		print(f"Item '{item}' replace at ({line}, {col}).")

	def remove_item(self, inv, line, col):
		if inv[line][col] is not None:
			item_deleted = inv[line][col]
			inv[line][col] = None
			print(f"Item '{item_deleted}' deleted at ({line}, {col}).")
		else:
			print(f"None item to deleted ({line}, {col}).")

	def show_inventory(self, inv):
		for line in inv:
			print(line)
   
	def find_space_empty(self, inv):
		for i, line in enumerate(inv):
			for j, cel in enumerate(line):
				if cel is None:
					return (i, j)
		return None

	def find_item(self, inv, item_name):
		for i, line in enumerate(inv):
			for j, cel in enumerate(line):
				if cel is not None and item_name in cel:
					return {
						"item": item_name,
						"value": cel[item_name],
						"position": (i, j)
					}
		return None

	def update_slot_selected(self):
		description: cave.UIElementComponent = self.entity.getChild("Inventory System").getChild("Menu Inventory").getChild("Slot Selected").getChild("Description").get("UIElementComponent")
		if self.inventory[0][self.currentSlot] is None:
			description.text = str("Empty slot")
		else:
			for key, value in self.inventory[0][self.currentSlot].items():
				if key == "ammo":
					description.text = str("Supplies of ammo")
				elif key == "health":
					description.text = str("Recovers health")
				elif key == "flashlight":
					description.text = str("Provides light in dark areas")
				elif key == "card":
					description.text = str("Used to open locked doors")

	def update_slots(self):
		if self.inventory is None:
			return
		slots = self.slots.getChildren()
		for i, slot in enumerate(slots):
			value = slot.getChild("Slot Value")
			if value is None:
				return
			ui_element: cave.UIElementComponent = value.get("UIElementComponent")
			if not self.inventory[0][i]:
				ui_element.text = str("")
			elif self.inventory[0][i] is not None:
				for key, value in self.inventory[0][i].items():
					ui_element.text = str(value)
 
	def update_selectors(self):
		slotSelector: cave.UIElementComponent = self.entity.getChild("Inventory System").getChild("Menu Inventory").getChild("Slot Selector").get("UIElementComponent")
		slotSelector.position.relative = self.slotPositions[self.currentSlot]
 
	def move_selector(self, direction: str):
		if direction == "right" and self.currentSlot < len(self.slotPositions) - 1:
			self.currentSlot += 1
		elif direction == "left" and self.currentSlot > 0:
			self.currentSlot -= 1
   
		sd = cave.playSound("Button Hover")
		if sd:
			sd.volume = cave.random.uniform(0.2, 0.5)
			sd.pitch  = cave.random.uniform(0.8, 1.2)

	def start(self, scene: cave.Scene):
		self.scene: cave.Scene = scene

		self.inventory = None
		if self.entity.getChild("Inventory System") is not None:
			self.slots: cave.Entity = self.entity.getChild("Inventory System").getChild("Menu Inventory").getChild("Slots")
			self.slotPositions = []
			self.currentSlot = 0
			for slot in self.slots.getChildren():
				self.slotPositions.append(slot.get("UIElementComponent").position.relative)
			
			self.inventory = [[None for _ in range(len(self.slotPositions))] for _ in range(1)]
			self.update_slots()
  
	def update(self):
		pass
		
	def pausedUpdate(self):
		print(self.inventory)

		events = cave.getEvents()
  
		if events.pressed(cave.event.KEY_D):
			self.move_selector("right")
		elif events.pressed(cave.event.KEY_A):
			self.move_selector("left")
		elif events.released(cave.event.MOUSE_MIDDLE):
			self.remove_item(self.inventory, 0, self.currentSlot)

		self.update_selectors()
		self.update_slots()
		self.update_slot_selected()
  
	def end(self, scene: cave.Scene):
		pass
	