import cave

class InteractionController(cave.Component):
	threshold: float = 3.0
	overrideInventorySlot: bool = True
 
	def setInventory(self, tag: str, obj: cave.Entity):
		inventoryController = self.entity.getPy("InventoryController")
		inventory = inventoryController.inventory

		findItem = inventoryController.find_item(inventory, tag) if self.overrideInventorySlot else None
		spaceEmpty = inventoryController.find_space_empty(inventory)
		item_value = obj.properties["value"]

		if findItem is not None:
			new_value = findItem["value"] + item_value
			inventoryController.replace_item(inventory, {tag: new_value}, findItem["position"][0], findItem["position"][1])
			obj.kill()
		elif spaceEmpty is not None:
			inventoryController.add_item(inventory, {tag: item_value}, spaceEmpty[0], spaceEmpty[1])
			obj.kill()
		else:
			print("No space in inventory")
 
	def start(self, scene: cave.Scene):
		self.scene = scene
		self.entity.getChild("UI").getChild("Interact").setActive(False, scene)

	def update(self):
		events = cave.getEvents()
		raycast: cave.RayCastOut = self.entity.getPy("RaycastComponent").result

		if raycast is not None and raycast.hit:
			obj = raycast.entity
			distance = (self.entity.getTransform().getWorldPosition() - raycast.position).length()

			if isinstance(obj, cave.Entity) and obj.hasTag("interact") and distance < self.threshold:
				self.entity.getChild("UI").getChild("Interact").setActive(True, self.scene)

				if events.pressed(cave.event.KEY_E):
					if obj.hasTag("ammo"):
						self.setInventory('ammo', obj)
					elif obj.hasTag("health"):
						self.setInventory('health', obj)
					elif obj.hasTag("flashlight"):
						self.setInventory('flashlight', obj)
					elif obj.hasTag("card"):
						self.setInventory('card', obj)
			else:
				self.entity.getChild("UI").getChild("Interact").setActive(False, self.scene)
	 
		
	def end(self, scene: cave.Scene):
		pass
	