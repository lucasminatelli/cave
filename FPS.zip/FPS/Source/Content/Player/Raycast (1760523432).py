import cave

class RaycastComponent(cave.Component):
	maskNumber =  7
	rayDistance = 1000
	debug: bool = True
 
	def start(self, scene: cave.Scene):
		self.scene = scene
		self.camera = scene.getCamera()
		self.result: cave.RayCastOut = None

	def update(self):
		origin = self.camera.getWorldPosition()
		target = origin + self.camera.getForwardVector(True) * -self.rayDistance
		mask = cave.BitMask(False)
		mask.enable(self.maskNumber)
		self.result = self.scene.rayCast(origin, target, mask)
  
		if self.result.hit and self.debug:
			self.scene.addDebugSphere(self.result.position, .2, cave.Vector3(1, 0, 0))
			
	def end(self, scene: cave.Scene):
		pass
	