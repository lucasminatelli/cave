import cave

class ShootController(cave.Component):
	def start(self, scene: cave.Scene):
		self.scene = scene

	def update(self):
		events = cave.getEvents()
     
		self.raycast: cave.RayCastOut = self.entity.getPy("RaycastComponent").result

		if self.raycast != None:
			if events.pressed(cave.event.MOUSE_LEFT):
				if self.raycast.hit:
					if self.raycast.entity.hasTag("enemy"):
						self.raycast.entity.kill()

	def end(self, scene: cave.Scene):
		pass
	